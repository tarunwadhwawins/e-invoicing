/*****************************************************************************************************************************************
 * Created By : Saddam Husain
 * Created Date : 02/05/2021
 * Description : This file is used for most commonly imported library and files that used in most all the components of application.   
 *****************************************************************************************************************************************/

// redux connector with react

export * as env from '../../../config/env.config';
