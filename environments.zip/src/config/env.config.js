export const NODE_ENV = process.env.REACT_APP_NODE_ENV;
export const API_URL = process.env.REACT_APP_API_URL;
export const PUBLIC_URL = process.env.REACT_APP_PUBLIC_URL;
export const DEFAULT_COUNTRY = process.env.REACT_APP_DEFAULT_COUNTRY;
export const APPLICATION_ID = process.env.REACT_APP_APPLICATION_ID;