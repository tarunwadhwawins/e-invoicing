import { useContext, useState } from "react"
import { StepperContext, Steps } from "../../Home"
import { Grid, Button, Form, Table, Icon, Label, } from "semantic-ui-react"
import { Link } from 'react-router-dom'
import AddMemberModal from "./AddMemberModal";


const ForthComponent = () => {
    const { activeStep, setActiveStep } = useContext(StepperContext)
    const [showAddMemberModal,setShowAddMemberModal] = useState(false)

    return (
        <Form size='large'>
            <AddMemberModal open={showAddMemberModal} setOpen={setShowAddMemberModal} />
            <Grid>
                <Grid.Column width={16} textAlign="right">
                    <Button onClick={()=>setShowAddMemberModal(true)} className="btn-secondary"><Icon name="plus"/> New Member</Button>
                </Grid.Column>
                <Grid.Column width={16}>
                    <div className="commonTable">
                        <Table singleLine>
                            <Table.Header>
                                <Table.Row>
                                    <Table.HeaderCell>Name <Icon name="sort" /></Table.HeaderCell>
                                    <Table.HeaderCell>Email <Icon name="sort" /></Table.HeaderCell>
                                    <Table.HeaderCell>Phone  <Icon name="sort" /></Table.HeaderCell>
                                    <Table.HeaderCell>Designation <Icon name="sort" /></Table.HeaderCell>
                                    <Table.HeaderCell>Roles <Icon name="sort" /></Table.HeaderCell>
                                    <Table.HeaderCell>Active/Inactive <Icon name="sort" /></Table.HeaderCell>
                                    <Table.HeaderCell>Actions</Table.HeaderCell>
                                </Table.Row>
                            </Table.Header>

                            <Table.Body>
                                <Table.Row>
                                    <Table.Cell><Link>Smith</Link></Table.Cell>
                                    <Table.Cell><Link>smith87@gmail.com</Link></Table.Cell>
                                    <Table.Cell>(789)-456-995</Table.Cell>
                                    <Table.Cell>Administrative</Table.Cell>
                                    <Table.Cell>
                                        <Label color='green'>Admin</Label>
                                    </Table.Cell>
                                    <Table.Cell><Form.Checkbox className="commonToggle" toggle /></Table.Cell>
                                    <Table.Cell>
                                        <Icon name="pencil" color='green' link />
                                        <Icon name="trash alternate" color='red' link />
                                    </Table.Cell>
                                </Table.Row>
                                <Table.Row>
                                    <Table.Cell><Link>Joseph</Link></Table.Cell>
                                    <Table.Cell><Link>joseph77@gmail.com</Link></Table.Cell>
                                    <Table.Cell>(557)-887-678</Table.Cell>
                                    <Table.Cell>Manager</Table.Cell>
                                    <Table.Cell>
                                        <Label color='green'>Admin</Label>
                                    </Table.Cell>
                                    <Table.Cell><Form.Checkbox className="commonToggle" toggle /></Table.Cell>
                                    <Table.Cell>
                                        <Icon name="pencil" color='green' link />
                                        <Icon name="trash alternate" color='red' link />
                                    </Table.Cell>
                                </Table.Row>
                                <Table.Row>
                                    <Table.Cell><Link>Robert</Link></Table.Cell>
                                    <Table.Cell><Link>robert77@gmail.com</Link></Table.Cell>
                                    <Table.Cell>(366)-777-333</Table.Cell>
                                    <Table.Cell>Executive</Table.Cell>
                                    <Table.Cell>
                                        <Label color='blue'>Sub-admin</Label>
                                    </Table.Cell>
                                    <Table.Cell><Form.Checkbox className="commonToggle" toggle /></Table.Cell>
                                    <Table.Cell>
                                        <Icon name="pencil" color='green' link />
                                        <Icon name="trash alternate" color='red' link />
                                    </Table.Cell>
                                </Table.Row>
                            </Table.Body>
                        </Table>
                    </div>
                </Grid.Column>
                <Grid.Column width={16} textAlign="right">
                    <Button className="btn-primary" onClick={() => setActiveStep(Steps.Third)}>Back</Button>
                </Grid.Column>
            </Grid>
        </Form>
    );
};

export default ForthComponent;