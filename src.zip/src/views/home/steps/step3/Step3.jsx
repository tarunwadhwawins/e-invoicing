import { useContext } from "react"
import { Button, Grid, Icon, Table, Tab } from "semantic-ui-react"
import { StepperContext, Steps } from "../../Home"

const panes = [
    {
        menuItem: 'Company Agreement',
        render: () =>
            <Tab.Pane>
                <div className="commonTable">
                    <Table singleLine>
                        <Table.Header>
                            <Table.Row>
                                <Table.HeaderCell>Agreement <Icon name="sort" /></Table.HeaderCell>
                                <Table.HeaderCell>Actions</Table.HeaderCell>
                            </Table.Row>
                        </Table.Header>

                        <Table.Body>
                            <Table.Row>
                                <Table.Cell>Agreement One</Table.Cell>
                                <Table.Cell>
                                    <Icon name="pencil" color='green' link />
                                    <Icon name="trash alternate" color='red' link />
                                </Table.Cell>
                            </Table.Row>
                            <Table.Row>
                                <Table.Cell>Agreement Two</Table.Cell>
                                <Table.Cell>
                                    <Icon name="pencil" color='green' link />
                                    <Icon name="trash alternate" color='red' link />
                                </Table.Cell>
                            </Table.Row>
                        </Table.Body>
                    </Table>
                </div>
            </Tab.Pane>,
    },
    {
        menuItem: 'Customer Agreement',
        render: () =>
            <Tab.Pane>
                <div className="commonTable">
                    <Table singleLine>
                        <Table.Header>
                            <Table.Row>
                                <Table.HeaderCell>Agreement <Icon name="sort" /></Table.HeaderCell>
                                <Table.HeaderCell>Actions</Table.HeaderCell>
                            </Table.Row>
                        </Table.Header>

                        <Table.Body>
                            <Table.Row>
                                <Table.Cell>Agreement Four</Table.Cell>
                                <Table.Cell>
                                    <Icon name="pencil" color='green' link />
                                    <Icon name="trash alternate" color='red' link />
                                </Table.Cell>
                            </Table.Row>
                            <Table.Row>
                                <Table.Cell>Agreement Five</Table.Cell>
                                <Table.Cell>
                                    <Icon name="pencil" color='green' link />
                                    <Icon name="trash alternate" color='red' link />
                                </Table.Cell>
                            </Table.Row>
                            <Table.Row>
                                <Table.Cell>Agreement Six</Table.Cell>
                                <Table.Cell>
                                    <Icon name="pencil" color='green' link />
                                    <Icon name="trash alternate" color='red' link />
                                </Table.Cell>
                            </Table.Row>
                        </Table.Body>
                    </Table>
                </div>
            </Tab.Pane>,
    },
]


const ThirdComponent = () => {

    const { activeStep, setActiveStep } = useContext(StepperContext)
    return (
        <Grid>
            <Grid.Column width={16}>
                <Tab menu={{ secondary: true }} panes={panes}  className="agreementTabs"/>
            </Grid.Column>
            <Grid.Column width={16} textAlign="right">
                <Button className="btn-primary" onClick={() => setActiveStep(Steps.Second)}>Back</Button>
                <Button className="btn-secondary" onClick={() => setActiveStep(Steps.Fourth)}>Next</Button>
            </Grid.Column>
        </Grid>
    )

}

export default ThirdComponent