import React, { createContext, useContext, useMemo, useState } from 'react'
import { Step, Grid, Header, Image } from 'semantic-ui-react'
import FirstComponent from './steps/step1/Step1'
import SecondComponent from './steps/step2/Step2'
import ThirdComponent from './steps/step3/Step3'
import ForthComponent from './steps/step4/Step4'
import Business from "../../assets/images/business.svg"
import Catalogue from "../../assets/images/catalogue.svg"
import Agreement from "../../assets/images/agreement.svg"
import Team from "../../assets/images/team.svg"
import Subscription from "../../assets/images/subscription-plan.svg"
import "./home.scss"
export const StepperContext = createContext(null)
export const Steps = {
    First: 'First',
    Second: "Second",
    Third: 'Third',
    Fourth: 'Fourth'
}

const Components = {
    First: FirstComponent,
    Second: SecondComponent,
    Third: ThirdComponent,
    Fourth: ForthComponent,
}

const Home = () => {

    const [activeStep, setActiveStep] = useState(Steps.First)

    const ActiveStep = Components[activeStep]

    const stepperContextValue = useMemo(() => ({ activeStep: activeStep, setActiveStep: setActiveStep }), [activeStep, setActiveStep])


    return (
        <>
            <Grid columns={5}>
                <Grid.Column>
                    <div className="settingBox">
                        <Image src={Business}/>
                        <Header as="h3">Business profile</Header>
                    </div>
                </Grid.Column>
                <Grid.Column>
                    <div className="settingBox">
                        <Image src={Catalogue}/>
                        <Header as="h3">Catalogue <br/><small>Product/Service</small></Header>
                    </div>
                </Grid.Column>
                <Grid.Column>
                    <div className="settingBox">
                        <Image src={Agreement}/>
                        <Header as="h3">Agreement</Header>
                    </div>
                </Grid.Column>
                <Grid.Column>
                    <div className="settingBox">
                        <Image src={Team}/>
                        <Header as="h3">Team</Header>
                    </div>
                </Grid.Column>
                <Grid.Column>
                    <div className="settingBox">
                        <Image src={Subscription}/>
                        <Header as="h3">Subscription Plan</Header>
                    </div>
                </Grid.Column>
            </Grid>
            <Grid>
                <Grid.Column width={16}>
                    <Header as="h2">Company Profile Setup</Header>
                </Grid.Column>
                <Grid.Column width={16}>
                    <Step.Group ordered className="customStepper">
                        <Step onClick={()=>{
                            setActiveStep(Steps.First)
                        }} active={activeStep === Steps.First}>
                            <Step.Content>
                                <Step.Title>Business profile </Step.Title>
                            </Step.Content>
                        </Step>

                        <Step onClick={()=>{
                            setActiveStep(Steps.Second)
                        }} active={activeStep === Steps.Second}>
                            <Step.Content>
                                <Step.Title>Catalogue <small>(Product/Service)</small> </Step.Title>
                            </Step.Content>
                        </Step>

                        <Step onClick={()=>{
                            setActiveStep(Steps.Third)
                        }} active={activeStep === Steps.Third}>
                            <Step.Content>
                                <Step.Title>Agreements</Step.Title>
                            </Step.Content>
                        </Step>
                        <Step onClick={()=>{
                            setActiveStep(Steps.Fourth)
                        }} active={activeStep === Steps.Fourth}>
                            <Step.Content>
                                <Step.Title>Team</Step.Title>
                            </Step.Content>
                        </Step>
                    </Step.Group>
                </Grid.Column>
            </Grid>

            <StepperContext.Provider value={stepperContextValue} >
                <ActiveStep />
            </StepperContext.Provider>

        </>
    )
}

export default Home
